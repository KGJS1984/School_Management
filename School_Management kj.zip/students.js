// Student Management System

let students = JSON.parse(localStorage.getItem("students")) || [];

// Auto Student ID
function generateStudentId() {
    return "STD" + (students.length + 1).toString().padStart(4, "0");
}

// Save Student
function saveStudent(e) {
    e.preventDefault();

    const student = {
        id: document.getElementById("studentId").value,
date: new Date().toLocaleDateString(),
        id: generateStudentId(),
        name: document.getElementById("studentName").value,
        father: document.getElementById("fatherName").value,
        mother: document.getElementById("motherName").value,
        mobile: document.getElementById("mobile").value,
        address: document.getElementById("address").value
    };

    students.push(student);

    localStorage.setItem("students", JSON.stringify(students));

    alert("Student Saved Successfully");

    document.getElementById("studentForm").reset();
}

// Show Students
function loadStudents() {

    const table = document.getElementById("studentTable");

    if (!table) return;

    table.innerHTML = "";

    students.forEach((student, index) => {

        table.innerHTML += `
        <tr>
            <td>${student.id}</td>
            <td>${student.name}</td>
            <td>${student.mobile}</td>

            <td>
                <button class="btn btn-warning btn-sm"
                onclick="editStudent(${index})">
                Edit
                </button>

                <button class="btn btn-danger btn-sm"
                onclick="deleteStudent(${index})">
                Delete
                </button>
            </td>
        </tr>
        `;

    });

}

// Delete Student
function deleteStudent(index) {

    if (confirm("Delete this student?")) {

        students.splice(index, 1);

        localStorage.setItem("students", JSON.stringify(students));

        loadStudents();

    }

}

// Edit Student
function editStudent(index) {

    let student = students[index];

    document.getElementById("studentName").value = student.name;
    document.getElementById("fatherName").value = student.father;
    document.getElementById("motherName").value = student.mother;
    document.getElementById("mobile").value = student.mobile;
    document.getElementById("address").value = student.address;

    students.splice(index, 1);
    localStorage.setItem("students", JSON.stringify(students));

}

// Search Student
function searchStudent(keyword) {

    keyword = keyword.toLowerCase();

    const rows = document.querySelectorAll("#studentTable tr");

    rows.forEach(row => {

        row.style.display =
            row.innerText.toLowerCase().includes(keyword)
                ? ""
                : "none";

    });

}

// Auto Load
window.onload = loadStudents;
function previewPhoto(event){

    let reader = new FileReader();

    reader.onload = function(){

        document.getElementById("photoPreview").src = reader.result;

    }

    reader.readAsDataURL(event.target.files[0]);

}
// Auto Student ID
function setStudentId() {

    let students = JSON.parse(localStorage.getItem("students")) || [];

    let nextId = "STD" + String(students.length + 1).padStart(4, "0");

    let studentIdInput = document.getElementById("studentId");

    if(studentIdInput){
        studentIdInput.value = nextId;
    }
}

window.onload = function(){

    loadStudents();

    setStudentId();

}